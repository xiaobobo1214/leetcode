/*
 * Baijiahulian.com Inc. Copyright (c) 2014-2019 All Rights Reserved.
 */
#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
 * @Classname ${NAME}
 * @Date ${DATE} ${TIME}
 * @Author xiaobobo
 * @Created by wangbo16@baijia.com
 */
public class ${NAME} {
}
